# stored procedures

USE employees;

DROP PROCEDURE IF EXISTS select_employees;
# when dropping a nonparametrised procedure then no parenthesis at the eind

DELIMITER //
CREATE PROCEDURE select_employees()
BEGIN
		SELECT * FROM employees
        LIMIT 1000;
END//

DELIMITER ;

CALL employees.select_employees();

CALL select_employees();

DELIMITER //
CREATE PROCEDURE avg_salary()
BEGIN
                SELECT
                                AVG(salary)
                FROM
                                salaries;
END//
DELIMITER ;

CALL avg_salary;
CALL avg_salary();
CALL employees.avg_salary;
CALL employees.avg_salary();

DROP PROCEDURE select_employees;

DROP PROCEDURE IF EXISTS emp_salary;

DELIMITER $$
USE employees $$
CREATE PROCEDURE emp_salary(IN p_emp_no INTEGER)
BEGIN
SELECT
	e.first_name, e.last_name, s.salary, s.from_date, s.to_date
FROM
	employees e
		JOIN
	salaries s on e.emp_no = s.emp_no
WHERE
	e.emp_no = p_emp_no;
END $$

DELIMITER ;

DELIMITER $$
USE employees $$
CREATE PROCEDURE emp_avg_salary_out(in p_emp_no INTEGER, out p_avg_salary DECIMAL(10,2))
BEGIN
SELECT
	AVG(s.salary)
INTO p_avg_salary FROM  # needs to be INTO for OUT parameter
	employees e
		JOIN
	salaries s on e.emp_no = s.emp_no
WHERE
	e.emp_no = p_emp_no;
END $$

DELIMITER ;

DELIMITER $$

USE employees $$

CREATE PROCEDURE emp_info(in p_first_name VARCHAR(255),
							in p_last_name VARCHAR(255),
                            out p_emp_no INTEGER)
BEGIN
	SELECT
		e.emp_no
    INTO
		p_emp_no FROM employees e
    WHERE
		e.first_name = p_first_name
	AND
        e.last_name = p_last_name;
END $$

DELIMITER ;

SELECT first_name, last_name FROM employees limit 10;

# creating variables

SET @v_avg_salary = 0;
CALL employees.emp_avg_salary_out(11300, @v_avg_salary);
SELECT @v_avg_salary;

SET @v_emp_no = 0;
CALL employees.emp_info('Aruna','Journel',@v_emp_no);
SELECT @v_emp_no;

# functions

DELIMITER $$
CREATE FUNCTION f_emp_avg_salary(p_emp_no INTEGER) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN

DECLARE v_avg_salary DECIMAL(10,2);

SELECT
	AVG(s.salary)
INTO v_avg_salary FROM
	employees e
		JOIN
	salaries s ON e.emp_no = s.emp_no
WHERE
	e.emp_no = p_emp_no;

RETURN v_avg_salary;
END $$
DELIMITER ;

SELECT f_emp_avg_salary(11300);

DROP FUNCTION IF EXISTS emp_info;

DELIMITER $$
USE employees $$
CREATE FUNCTION emp_info(f_first_name VARCHAR(255),
						f_last_name VARCHAR(255))
					RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
	DECLARE max_date DATE;
	DECLARE _salary DECIMAL(10,2);

	SELECT MAX(s.from_date)
	INTO max_date FROM salaries s
		JOIN
		employees e on s.emp_no = e.emp_no
	WHERE
		e.first_name = f_first_name
	AND
		e.last_name = f_last_name;

	SELECT s.salary
    INTO _salary FROM salaries s
		JOIN
		employees e on s.emp_no = e.emp_no
	WHERE
		e.first_name = f_first_name
	AND
		e.last_name = f_last_name
	AND
		s.from_date = max_date;
RETURN _salary;
END $$
DELIMITER ;

SELECT emp_info('Parto','Bamford');

# procedure in SELECT - possible, function not
SET @v_emp_no = 11300;
SELECT
	emp_no,
    first_name,
    last_name,
    f_emp_avg_salary(@v_emp_no) AS avg_salary
FROM
	employees
WHERE
	emp_no = @v_emp_no;