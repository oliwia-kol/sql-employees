# select from

SELECT 
    first_name, last_name
FROM
    employees;

# select *    

SELECT 
    *
FROM
    employees;

# select from where

SELECT 
    *
FROM
    employees
WHERE
    first_name = 'Elvis';

# select from where and 
    
SELECT 
    *
FROM
    employees
WHERE
    first_name = 'Kellie' AND gender = 'F';
    
# select from where or 

SELECT 
    *
FROM
    employees
WHERE
    first_name = 'Kellie' OR first_name = 'Aruna';
    
# logical select or/and

SELECT 
    *
FROM
    employees
WHERE
    gender = 'F'
        AND (first_name = 'Kellie'
        OR first_name = 'Aruna');
        
# select from where 3 options

SELECT 
    *
FROM
    employees
WHERE
    first_name = 'Cathie'
        OR first_name = 'Mark'
        OR first_name = 'Nathan';
        
# or

SELECT 
    *
FROM
    employees
WHERE
    first_name IN ('Cathie', 'Mark', 'Nathan');

# or not in
    
    SELECT 
    *
FROM
    employees
WHERE
    first_name NOT IN ('Cathie', 'Mark', 'Nathan');
    
# pattern with one letter

SELECT 
    *
FROM
    employees
WHERE
    first_name LIKE ('Mar_');
    
# not pattern with more letters

SELECT 
    *
FROM
    employees
WHERE
    first_name NOT LIKE ('Mar%');
    
select * from employees where first_name like ('Mar%');
select * from employees where hire_date like('2000%');
select * from employees where emp_no like ('1000_');

select * from employees where first_name not like('%jack%');

# (not/) between and

SELECT 
    *
FROM
    employees
WHERE
    hire_date NOT BETWEEN '1990-01-01' AND '2000-01-01';
    
select * from salaries where salary between 66000 and 70000;
select * from employees where emp_no not between 10004 and 10012;
select * from departments where dept_no between 'd003' and 'd006';

# is (not/) null

SELECT 
    *
FROM
    employees
WHERE
    first_name IS NULL;
    
select * from departments where dept_name is not null;

# operators

SELECT 
    *
FROM
    employees
WHERE
    gender = 'F'
        AND hire_date >= '2000-01-01';
SELECT 
    *
FROM
    salaries
WHERE
    salary > 150000;
    
# select distinct == unique

SELECT DISTINCT
    gender
FROM
    employees;

select distinct hire_date from employees;

# count - zlicza liczbe wartosci

SELECT 
    COUNT(emp_no)
FROM
    employees;
    
# count distinct names - zwraca ilosc roznych imion

SELECT 
    COUNT(DISTINCT (first_name))
FROM
    employees;
    
select count(*) from salaries where salary > 10000;
select count(*) from dept_manager;
select count(*) from titles where title like ('%manager%');

# order by asc - ascending (default), desc

SELECT 
    *
FROM
    employees
ORDER BY first_name, last_name DESC;

# group by - grupuje takie same rekordy; alias

SELECT 
    first_name, COUNT(first_name) AS names_count
FROM
    employees
GROUP BY first_name
ORDER BY first_name;

# zadanie

select salary, count(*) as emps_with_same_salary
from salaries
where salary > 80000
group by salary
order by salary;

# having

SELECT 
    *
FROM
    employees
WHERE 		# HAVING - for aggregate functions: count, sum, avg, max, min
    hire_date >= '2000-01-01';
    
SELECT 
    first_name, COUNT(first_name) AS names_count
FROM
    employees
# WHERE
GROUP BY first_name
HAVING
    COUNT(first_name) > 250
ORDER BY first_name;

select emp_no, avg(salary)
from salaries
group by emp_no
having avg(salary) > 120000
order by emp_no;

# where and having

SELECT 
    first_name, COUNT(first_name)
FROM
    employees
WHERE
    hire_date > '1999-01-01'
GROUP BY first_name
HAVING COUNT(first_name) < 200
ORDER BY first_name DESC;

select emp_no, count(emp_no)
from dept_emp
where from_date > '2000-01-01'
group by emp_no
having count(from_date) > 1
order by emp_no;

# limit

SELECT 
    *
FROM
    salaries
ORDER BY salary DESC
LIMIT 10;

select * from dept_emp limit 100;

# insert into

SELECT 
    *
FROM
    employees
ORDER BY emp_no DESC
LIMIT 10;

INSERT INTO employees (
	emp_no,
    birth_date,
    first_name,
    last_name,
    gender,
    hire_date
)
VALUES (
	999901,
    '1986-04-21',
    'John',
    'Smith',
    'M',
    '2011-01-01'
);

INSERT INTO employees (
    birth_date,
    emp_no,
    first_name,
    last_name,
    gender,
    hire_date
)
VALUES (
    '1973-03-26',
	 999902,
    'Patricia',
    'Lawrence',
    'F',
    '2005-01-01'
);

INSERT INTO employees
VALUES (
	999903,
    '1977-09-14',
    'Jonathan',
    'Creek',
    'M',
    '1999-01-01'
);

insert into titles (emp_no, title, from_date)
values (999903, 'Senior Engineer', '1997-10-01');

select * from titles
order by title desc
limit 10;

select * from dept_emp
order by emp_no desc
limit 10; 

insert into dept_emp
values (999903, 'd005', '1997-10-01', '9999-01-01');

# insert into select from

SELECT 
    *
FROM
    departments
LIMIT 10;

CREATE TABLE departments_dup (
    dept_no CHAR(4) NOT NULL,
    dept_name VARCHAR(40) NOT NULL
);

INSERT INTO departments_dup
(
dept_no,
dept_name
)
SELECT 
	*
FROM
departments;

SELECT 
    *
FROM
    departments
ORDER BY dept_name asc;

INSERT INTO departments
VALUES (
	'd010',
    'Buisness Analysis'
);
