select * from departments_dup;

insert into departments_dup(dept_no)
values ('d010'), ('d011');

delete from departments_dup
where dept_no = 'd002';

drop table if exists dept_manager_dup;
create table dept_manager_dup (
	emp_no int(11) NOT NULL,
    dept_no char(4) NULL,
    from_date date NOT NULL,
    to_date date NULL
);
insert into dept_manager_dup
select * from dept_manager;

select * from dept_manager_dup order by emp_no desc;

insert into dept_manager_dup(emp_no, from_date)
values (999904, '2017-01-01'),
	(999905, '2017-01-01'),
	(999906, '2017-01-01'),
    (999907, '2017-01-01');
    
delete from dept_manager_dup where dept_no = 'd001';

# INNER JOIN - only joins when columns match, null values don't appear

select * from departments_dup order by dept_no;
select * from dept_manager_dup order by dept_no;

SELECT 
    m.dept_no, m.emp_no, d.dept_name
FROM
    dept_manager_dup m
        INNER JOIN
    departments_dup d ON m.dept_no = d.dept_no
ORDER BY m.dept_no;

select m.emp_no, e.first_name, e.last_name, m.dept_no, m.from_date
from dept_manager_dup m
inner join employees e on m.emp_no = e.emp_no
order by m.emp_no;

# duplicate records

INSERT INTO dept_manager_dup
VALUES ('110228', 'd003', '1992-03-21', '9999-01-01');

INSERT INTO departments_dup
VALUES ('d009', 'Customer Service');

SELECT 
    *
FROM
    dept_manager_dup
ORDER BY dept_no ASC;

SELECT 
    *
FROM
    departments_dup
ORDER BY dept_no ASC;

SELECT 
    m.dept_no, m.emp_no, d.dept_name
FROM
    dept_manager_dup m
        INNER JOIN
    departments_dup d ON m.dept_no = d.dept_no
GROUP BY m.emp_no
ORDER BY dept_no;

 # left join
 
DELETE FROM dept_manager_dup 
WHERE
    emp_no = '110228';
    
DELETE FROM departments_dup 
WHERE
    dept_no = 'd009';
    
  # add back deleted records
INSERT INTO dept_manager_dup
VALUES ('110228', 'd003', '1992-03-21', '9999-01-01');

INSERT INTO departments_dup
VALUES ('d009', 'Customer Service');

# left join

SELECT 
    m.dept_no, m.emp_no, d.dept_name
FROM
    dept_manager_dup m
        LEFT JOIN
    departments_dup d ON m.dept_no = d.dept_no
WHERE
    dept_name IS NULL
ORDER BY m.dept_no;

select e.emp_no, e.first_name, e.last_name, m.dept_no, m.from_date
from employees e
left join dept_manager m on e.emp_no = m.emp_no
where e.last_name = 'Markovitch'
order by e.emp_no desc;

# right join

SELECT 
    d.dept_no, m.emp_no, d.dept_name
FROM
    departments_dup d
        RIGHT JOIN
    dept_manager_dup m ON m.dept_no = d.dept_no
ORDER BY dept_no;

# join by where

SELECT 
    m.dept_no, m.emp_no, d.dept_name
FROM
    dept_manager_dup m,
    departments_dup d
WHERE
    m.dept_no = d.dept_no
ORDER BY m.dept_no;

select e.emp_no, e.first_name, e.last_name, m.dept_no, m.from_date
from employees e, dept_manager_dup m
where e.emp_no = m.emp_no
order by e.emp_no desc;

# join where

SELECT 
    e.emp_no, e.first_name, e.last_name, s.salary
FROM
    employees e
        JOIN
    salaries s ON e.emp_no = s.emp_no
WHERE
    s.salary > 125000
ORDER BY emp_no;

# usuwanie bledu 1055

# SET @@sql_mode = SYS.LIST_DROP(@@sql_mode, 'ONLY_FULL_GROUP_BY');
# SELECT @@sql_mode;

select e.emp_no, e.first_name, e.last_name, e.hire_date, t.title
from employees e
join titles t on e.emp_no = t.emp_no
where e.first_name = 'Margareta' and e.last_name = 'Markovitch'
group by e.emp_no;

# cross join - connects all the values, not just those that match; cartesian product

SELECT 
    dm.*, d.*
FROM
    dept_manager dm
        CROSS JOIN
    departments d
ORDER BY dm.emp_no, d.dept_no;

SELECT 
    dm.*, d.*
FROM
    dept_manager dm,
    departments d
ORDER BY dm.emp_no , d.dept_no;

SELECT 
    dm.*, d.*
FROM
    departments d
		CROSS JOIN
    dept_manager dm
WHERE
	d.dept_no <> dm.dept_no
ORDER BY dm.emp_no, d.dept_no;

SELECT 
    e.*, d.*
FROM
    departments d
		CROSS JOIN
    dept_manager dm
		JOIN
	employees e on e.emp_no = dm.emp_no
WHERE
	d.dept_no <> dm.dept_no
ORDER BY dm.emp_no, d.dept_no;

select
	d.*, dm.*
from departments d
	cross join
	dept_manager dm
where
	d.dept_no = 'd009';
    
select e.*, d.*
from employees e
	cross join
    departments d
where e.emp_no = 10011;

# aggregate functions with join

SELECT
	e.gender, AVG(s.salary) AS average_salary
FROM
	employees e
		JOIN
	salaries s ON e.emp_no = s.emp_no
GROUP BY gender;

SELECT
	e.first_name,
    e.last_name,
    e.hire_date,
    m.from_date,
    d.dept_name
FROM
	employees e
		JOIN
	dept_manager m ON e.emp_no = m.emp_no
		JOIN
	departments d ON m.dept_no = d.dept_no;
    
select e.first_name, e.last_name, e.hire_date,
		t.title, t.from_date, d.dept_name
from employees e
	join dept_manager dm on e.emp_no = dm.emp_no
    join departments d on dm.dept_no = d.dept_no
    join titles t on e.emp_no = t.emp_no
    group by e.last_name;
    
#deputy name + avg salary for managers in deputies

SELECT 
    d.dept_name, AVG(s.salary)
FROM
    departments d
        JOIN
    dept_manager dm ON d.dept_no = dm.dept_no
        JOIN
    salaries s ON s.emp_no = dm.emp_no
GROUP BY d.dept_name;

select e.gender, count(dm.emp_no)
from employees e
    join dept_manager dm on dm.emp_no = e.emp_no
group by e.gender;

# union and union all - combine a few select statements in single output
# they have to have same columns, if not make them

DROP TABLE IF EXISTS employees_dup;
CREATE TABLE employees_dup (
    emp_no INT(11),
    birth_date DATE,
    first_name VARCHAR(14),
    last_name VARCHAR(16),
    gender ENUM('M', 'F'),
    hire_date DATE
);
    
INSERT INTO employees_dup
SELECT
	e.*
FROM
	employees e
LIMIT 20;

SELECT 
    *
FROM
    employees_dup;
    
INSERT INTO employees_dup VALUES
('10001', '1953-09-02', 'Georgi', 'Facello', 'M', '1986-06-26');

SELECT
	e.emp_no,
    e.first_name,
    e.last_name,
    NULL AS dept_no,
    NULL AS from_date
FROM
	employees_dup e
WHERE
	e.emp_no = 10001
UNION /*ALL*/ SELECT
	NULL AS emp_no,
    NULL AS first_name,
    NULL AS last_name,
    m.dept_no,
    m.from_date
FROM
	dept_manager m;
    
# union all retrievs duplicates too

SELECT
    *
FROM
    (SELECT
        e.emp_no,
		e.first_name,
		e.last_name,
		NULL AS dept_no,
		NULL AS from_date
    FROM
        employees e
    WHERE
        last_name = 'Denis'
	UNION SELECT
        NULL AS emp_no,
		NULL AS first_name,
		NULL AS last_name,
		dm.dept_no,
		dm.from_date
    FROM
        dept_manager dm) as a
ORDER BY -a.emp_no DESC;

# subqueries

SELECT 
    *
FROM
    dept_manager;

SELECT
	e.first_name, e.last_name
FROM
	employees e
WHERE
	e.emp_no IN (SELECT
		dm.emp_no
	FROM
		dept_manager dm);
        
select e.first_name, e.last_name
from employees e
where e.emp_no in(select
		dm.emp_no
	from
		dept_manager dm
	where dm.from_date between '1990-01-01' and '1995-01-01');
    
# exists - not exists

SELECT
	e.first_name, e.last_name
FROM
	employees e
WHERE
	EXISTS(SELECT
			*
		FROM
			dept_manager dm
		WHERE
			dm.emp_no = e.emp_no);
            
SELECT
	e.first_name, e.last_name
FROM
	employees e
WHERE
	EXISTS(SELECT
			*
		FROM
			dept_manager dm
		WHERE
			dm.emp_no = e.emp_no)
ORDER BY
	emp_no;

#    UNION

SELECT 
    A.*
FROM
    (SELECT 
        e.emp_no AS employee_ID,
            MIN(de.dept_no) AS department_code,
            (SELECT 
                    emp_no
                FROM
                    dept_manager
                WHERE
                    emp_no = 110022) AS manager_ID
    FROM
        employees e
    JOIN dept_emp de ON e.emp_no = de.emp_no
    WHERE
        e.emp_no <= 10020
    GROUP BY e.emp_no
    ORDER BY e.emp_no) AS A 
UNION SELECT 
    B.*
FROM
    (SELECT 
        e.emp_no AS employee_ID,
            MIN(de.dept_no) AS department_code,
            (SELECT 
                    emp_no
                FROM
                    dept_manager
                WHERE
                    emp_no = 110039) AS manager_ID
    FROM
        employees e
    JOIN dept_emp de ON e.emp_no = de.emp_no
    WHERE
        e.emp_no BETWEEN 10021 AND 10040
    GROUP BY e.emp_no
    ORDER BY e.emp_no) AS B;
    
#  emp_manager union - zrobić samemu 

DROP TABLE IF EXISTS emp_manager;

CREATE TABLE emp_manager (
   emp_no INT(11) NOT NULL,
   dept_no CHAR(4) NULL,
   manager_no INT(11) NOT NULL
);

INSERT INTO emp_manager
SELECT 
    u.*
FROM
    (SELECT 
        a.*
    FROM
        (SELECT 
        e.emp_no AS employee_ID,
            MIN(de.dept_no) AS department_code,
            (SELECT 
                    emp_no
                FROM
                    dept_manager
                WHERE
                    emp_no = 110022) AS manager_ID
    FROM
        employees e
    JOIN dept_emp de ON e.emp_no = de.emp_no
    WHERE
        e.emp_no <= 10020
    GROUP BY e.emp_no
    ORDER BY e.emp_no) AS a UNION SELECT 
        b.*
    FROM
        (SELECT 
        e.emp_no AS employee_ID,
            MIN(de.dept_no) AS department_code,
            (SELECT 
                    emp_no
                FROM
                    dept_manager
                WHERE
                    emp_no = 110039) AS manager_ID
    FROM
        employees e
    JOIN dept_emp de ON e.emp_no = de.emp_no
    WHERE
        e.emp_no > 10020
    GROUP BY e.emp_no
    ORDER BY e.emp_no
    LIMIT 20) AS b UNION SELECT 
        c.*
    FROM
        (SELECT 
        e.emp_no AS employee_ID,
            MIN(de.dept_no) AS department_code,
            (SELECT 
                    emp_no
                FROM
                    dept_manager
                WHERE
                    emp_no = 110039) AS manager_ID
    FROM
        employees e
    JOIN dept_emp de ON e.emp_no = de.emp_no
    WHERE
        e.emp_no = 110022
    GROUP BY e.emp_no) AS c UNION SELECT 
        d.*
    FROM
        (SELECT 
        e.emp_no AS employee_ID,
            MIN(de.dept_no) AS department_code,
            (SELECT 
                    emp_no
                FROM
                    dept_manager
                WHERE
                    emp_no = 110022) AS manager_ID
    FROM
        employees e
    JOIN dept_emp de ON e.emp_no = de.emp_no
    WHERE
        e.emp_no = 110039
    GROUP BY e.emp_no) AS d) as u;

# self join

SELECT
	e1.*
FROM 
	emp_manager e1
		JOIN
	emp_manager e2 ON e1.emp_no = e2.emp_no
WHERE
	e2.emp_no IN (SELECT
			manager_no
        FROM
			emp_manager);
            
SELECT 
    manager_no
FROM
    emp_manager;
    
# views

SELECT 
    *
FROM
    dept_emp;
    
SELECT
	emp_no, from_date, to_date, COUNT(emp_no) AS Num
FROM
	dept_emp
GROUP BY emp_no
HAVING Num > 1;

CREATE OR REPLACE VIEW v_dept_emp_latest_date AS
	SELECT
		emp_no, MAX(from_date) as from_date, MAX(to_date) as to_date
	FROM
		dept_emp
	GROUP BY emp_no;