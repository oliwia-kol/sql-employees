# count(); if (*) then null values are included; also non-numeric

SELECT 
    *
FROM
    salaries
ORDER BY salary DESC
LIMIT 10;

SELECT 
    COUNT(*)
FROM
    salaries;

SELECT
	COUNT(DISTINCT dept_no)
FROM dept_emp;

# sum()

SELECT 
    SUM(salary)
FROM
    salaries;
    
select sum(salary)
from salaries
where from_date > '1997-01-01';

# max() and min()

SELECT 
/*MAX*/MIN(salary)
FROM
    salaries;

select MIN(emp_no) from employees;
select MAX(emp_no) from employees;

# avg()

SELECT 
    AVG(salary)
FROM
    salaries;
    
select avg(salary) from salaries where from_date > '1997-01-01';

# round(): np. round(float, 2)

SELECT 
    ROUND(AVG(salary), 2)
FROM
    salaries;
    
select round(avg(salary),2) from salaries where from_date > '1997-01-01';

# coalesce()

SELECT 
    *
FROM
    departments_dup;

ALTER TABLE departments_dup
CHANGE COLUMN dept_name dept_name VARCHAR(40) NULL;

INSERT INTO departments_dup(dept_no)
VALUES ('d010'), ('d011');

ALTER TABLE employees.departments_dup
ADD COLUMN dept_manager VARCHAR(255) NULL AFTER dept_name;

COMMIT;
ROLLBACK;

# ifnull(if_not_null; if_null) / coalesce(N arg; return first, single 
# non-null value in parenthesis)

SELECT 
    dept_no,
    IFNULL(dept_name,
            'Department name not provided') as 'dept_name'
FROM
    departments_dup;
    
SELECT 
    dept_no,
    COALESCE(dept_name,
            'Department name not provided') as 'dept_name'
FROM
    departments_dup;
    
SELECT
	*
FROM
	departments_dup
ORDER BY dept_no;

SELECT
	dept_no,
    dept_name,
    COALESCE(dept_manager, dept_name, 'N/A') AS dept_manager
    # see is coalesce(if it is not null, if it is null, if it is null),
    # if it is then changes; if two first are null then writes third
FROM
	departments_dup
ORDER BY dept_no ASC;

# coalesce(can be ONE argument)

SELECT
	dept_no,
    dept_name,
    COALESCE('department manager name') as fake_col
FROM
	departments_dup;
    
select
	dept_no,
    dept_name,
    coalesce(dept_no, dept_name) as dept_info
from departments_dup
order by dept_no asc;

select
	ifnull(dept_no, 'N/A') as dept_no,
    ifnull(dept_name, 'Department not provided') as dept_name,
    coalesce(dept_no, dept_name) as dept_info
from departments_dup
order by dept_no asc;