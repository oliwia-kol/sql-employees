# update

USE employees;

SELECT 
    *
FROM
    employees
WHERE
    emp_no = 999901;
    
UPDATE employees
SET
	first_name = 'Stella',
    last_name = 'Parkinson',
    birth_date = '1990-12-31',
    gender = 'F'
WHERE
	emp_no = 999901;
    
#

DROP TABLE departments_dup;

SELECT
	*
FROM
	departments_dup
ORDER BY dept_no;

COMMIT;

UPDATE departments_dup
SET
	dept_no = 'd011',
    dept_name = 'Quality Control';
    
ROLLBACK; 

select * from departments;

update departments
set
	dept_name = 'Data Analysis'
where dept_no = 'd010';

# delete from where

USE employees;

COMMIT;

SELECT 
	*
FROM
	titles
WHERE
	emp_no = 999903;
    
DELETE FROM employees
WHERE
	emp_no = 999903;
    
ROLLBACK;

# delete 

SELECT
	*
FROM 
	departments
ORDER BY dept_no;

DELETE FROM departments_dup;

ROLLBACK;

DELETE FROM departments
WHERE
	dept_no = 'd010';
    
# drop, truncate, delete
# drop - remove whole table etc without a step back
# truncate - delete without where - remove all data from a table,
# 			 auto-increment reset
# delete - removes record row by row, doesn't reset auto-increment